﻿# Operro Claude build packet

Base commit: 4902945 feat(parity): complete remaining HomePaw workstreams.

1. Read CLAUDE_BUILD_BRIEF.md in full.
2. Follow operro/apps/web/AGENTS.md before changing web code.
3. Treat this as curated context only; work in a clean checkout at the base commit, not inside this archive.
4. Do not access credentials, production, provider APIs, or files outside the supplied task scope.
5. Return an uncommitted patch plus the required handoff; do not push, deploy, merge, or apply remote migrations.
