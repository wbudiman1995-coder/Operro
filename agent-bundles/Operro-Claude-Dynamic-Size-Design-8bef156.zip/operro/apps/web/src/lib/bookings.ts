import type { SupabaseClient } from "@supabase/supabase-js";
import type { SpeciesPricing } from "@/lib/pet-sizing";

export interface BranchOption { id: string; name: string; timezone: string }
export interface CustomerOption { id: string; name: string; phone: string | null }
export interface PetOption { id: string; customerId: string; name: string; breed: string | null; species: string; size: string | null; weightKg: number | null }
export interface ServiceOption { id: string; name: string; category: string; durationMinutes: number; basePrice: number; currency: string; priceExtraSmall: number | null; priceSmall: number | null; priceMedium: number | null; priceLarge: number | null; priceExtraLarge: number | null; priceCat: number | null; durationExtraSmall: number | null; durationSmall: number | null; durationMedium: number | null; durationLarge: number | null; durationExtraLarge: number | null; durationCat: number | null; speciesPricing: SpeciesPricing }
export interface ResourceOption { id: string; branchId: string; name: string }
export interface CustomerPackageOption { id: string; customerId: string; name: string; serviceId: string | null; petId: string | null; sessionsRemaining: number; reservedSessions: number; availableSessions: number; expiresAt: string | null }
export interface AddressOption { id: string; customerId: string; label: string; formattedLine: string; kecamatan: string | null; kabupatenKota: string | null; latitude: number | null; longitude: number | null; isDefault: boolean }
export interface ServiceAreaOption { branchId: string; kecamatan: string | null; kabupatenKota: string; travelFee: number; estimatedTravelMinutes: number }
export interface NextDiscountOption { customerId: string; label: string; rules: Record<string, { type: string; value: number }>; expiresAt: string | null }
export interface BookingListItem {
  id: string;
  branchId: string;
  customerName: string;
  petNames: string[];
  startsAt: string;
  endsAt: string;
  status: string;
  fulfillmentMode: string;
}
export interface BookingWorkspaceData {
  branches: BranchOption[];
  customers: CustomerOption[];
  pets: PetOption[];
  services: ServiceOption[];
  resources: ResourceOption[];
  addresses: AddressOption[];
  serviceAreas: ServiceAreaOption[];
  nextDiscounts: NextDiscountOption[];
  customerPackages: CustomerPackageOption[];
  bookings: BookingListItem[];
}

function fail(scope: string, message: string) {
  throw new Error(`${scope}_failed:${message}`);
}

function relationRows(value: unknown): Record<string, unknown>[] {
  if (Array.isArray(value)) return value.filter((item): item is Record<string, unknown> => typeof item === "object" && item !== null);
  return typeof value === "object" && value !== null ? [value as Record<string, unknown>] : [];
}

function embeddedPetNames(value: unknown) {
  return relationRows(value).flatMap((job) => relationRows(job.grooming_job_pets)).flatMap((jobPet) => {
    const name = relationRows(jobPet.pets)[0]?.name;
    return typeof name === "string" ? [name] : [];
  });
}

export async function loadBookingWorkspace(
  supabase: SupabaseClient,
  organizationId: string,
  from: string,
  to: string,
): Promise<BookingWorkspaceData> {
  const [branchResult, customerResult, petResult, serviceResult, resourceResult, addressResult, serviceAreaResult, nextDiscountResult, packageResult, reservedResult, bookingResult] = await Promise.all([
    supabase.from("branches").select("id,name,timezone").eq("organization_id", organizationId).eq("status", "active").is("deleted_at", null).order("name"),
    supabase.from("customers").select("id,display_name,phone").eq("organization_id", organizationId).in("status", ["lead", "active"]).is("deleted_at", null).order("display_name"),
    supabase.from("pets").select("id,customer_id,name,breed,species,size,weight_kg").eq("organization_id", organizationId).eq("status", "active").is("deleted_at", null).order("name"),
    supabase.from("service_catalog").select("id,name,category,duration_minutes,base_price,currency,price_extra_small,price_small,price_medium,price_large,price_extra_large,price_cat,duration_extra_small,duration_small,duration_medium,duration_large,duration_extra_large,duration_cat,species_pricing").eq("organization_id", organizationId).eq("is_active", true).is("deleted_at", null).order("name"),
    supabase.from("resources").select("id,branch_id,name").eq("organization_id", organizationId).eq("kind", "staff").eq("status", "active").is("deleted_at", null).order("name"),
    supabase.from("customer_addresses").select("id,customer_id,label,line1,line2,kecamatan,kabupaten_kota,province,postal_code,latitude,longitude,is_default").eq("organization_id", organizationId).is("deleted_at", null).order("is_default", { ascending: false }),
    supabase.from("branch_service_areas").select("branch_id,kecamatan,kabupaten_kota,travel_fee,estimated_travel_minutes").eq("organization_id", organizationId).eq("is_active", true).is("deleted_at", null),
    supabase.from("customer_next_discounts").select("customer_id,label,rules,expires_at").eq("organization_id", organizationId).eq("status", "active").or(`expires_at.is.null,expires_at.gt.${new Date().toISOString()}`),
    supabase.from("customer_packages").select("id,customer_id,service_id,pet_id,sessions_remaining,expires_at,packages(name)").eq("organization_id", organizationId).eq("status", "active").gt("sessions_remaining", 0).is("deleted_at", null).or(`expires_at.is.null,expires_at.gt.${new Date().toISOString()}`),
    // Coverage detection (section 23): available = sessions_remaining - already-reserved,
    // so the wizard can warn before a selection collides with server-side availability.
    supabase.from("package_reservations").select("customer_package_id").eq("organization_id", organizationId).eq("status", "reserved"),
    supabase.from("bookings").select("id,branch_id,customer_id,starts_at,ends_at,status,fulfillment_mode,grooming_jobs(grooming_job_pets(pets(name)))").eq("organization_id", organizationId).gte("starts_at", from).lt("starts_at", to).is("deleted_at", null).order("starts_at"),
  ]);

  for (const [scope, result] of [["branches", branchResult], ["customers", customerResult], ["pets", petResult], ["services", serviceResult], ["resources", resourceResult], ["addresses", addressResult], ["service_areas", serviceAreaResult], ["next_discounts", nextDiscountResult], ["customer_packages", packageResult], ["package_reservations", reservedResult], ["bookings", bookingResult]] as const) {
    if (result.error) fail(scope, result.error.message);
  }

  const bookingRows = bookingResult.data ?? [];
  const customers = (customerResult.data ?? []).map((row) => ({ id: row.id, name: row.display_name, phone: row.phone }));
  const customerNames = new Map(customers.map((customer) => [customer.id, customer.name]));

  return {
    branches: (branchResult.data ?? []).map((row) => ({ id: row.id, name: row.name, timezone: row.timezone })),
    customers,
    pets: (petResult.data ?? []).map((row) => ({ id: row.id, customerId: row.customer_id, name: row.name, breed: row.breed, species: row.species, size: row.size, weightKg: row.weight_kg === null ? null : Number(row.weight_kg) })),
    services: (serviceResult.data ?? []).map((row) => ({ id: row.id, name: row.name, category: row.category?.trim() || "Lainnya", durationMinutes: row.duration_minutes, basePrice: Number(row.base_price), currency: row.currency, priceExtraSmall: row.price_extra_small === null ? null : Number(row.price_extra_small), priceSmall: row.price_small === null ? null : Number(row.price_small), priceMedium: row.price_medium === null ? null : Number(row.price_medium), priceLarge: row.price_large === null ? null : Number(row.price_large), priceExtraLarge: row.price_extra_large === null ? null : Number(row.price_extra_large), priceCat: row.price_cat === null ? null : Number(row.price_cat), durationExtraSmall: row.duration_extra_small, durationSmall: row.duration_small, durationMedium: row.duration_medium, durationLarge: row.duration_large, durationExtraLarge: row.duration_extra_large, durationCat: row.duration_cat, speciesPricing: row.species_pricing as SpeciesPricing })),
    resources: (resourceResult.data ?? []).map((row) => ({ id: row.id, branchId: row.branch_id, name: row.name })),
    nextDiscounts: (nextDiscountResult.data ?? []).map((row) => {
      const raw = row.rules && typeof row.rules === "object" && !Array.isArray(row.rules) ? row.rules as Record<string, unknown> : {};
      const rules = Object.fromEntries(Object.entries(raw).flatMap(([scope, value]) => {
        if (!value || typeof value !== "object" || Array.isArray(value)) return [];
        const rule = value as Record<string, unknown>; const amount = Number(rule.value);
        return typeof rule.type === "string" && Number.isFinite(amount) ? [[scope, { type: rule.type, value: amount }]] : [];
      }));
      return { customerId: row.customer_id, label: row.label, rules, expiresAt: row.expires_at };
    }),
    customerPackages: (() => {
      const reservedByPackage = new Map<string, number>();
      for (const row of reservedResult.data ?? []) reservedByPackage.set(row.customer_package_id, (reservedByPackage.get(row.customer_package_id) ?? 0) + 1);
      return (packageResult.data ?? []).map((row) => {
        const reserved = reservedByPackage.get(row.id) ?? 0;
        return {
          id: row.id,
          customerId: row.customer_id,
          name: (() => { const value = relationRows(row.packages)[0]?.name; return typeof value === "string" ? value : "Paket"; })(),
          serviceId: row.service_id,
          petId: row.pet_id,
          sessionsRemaining: row.sessions_remaining,
          reservedSessions: reserved,
          availableSessions: Math.max(0, row.sessions_remaining - reserved),
          expiresAt: row.expires_at,
        };
      });
    })(),
    addresses: (addressResult.data ?? []).map((row) => ({
      id: row.id,
      customerId: row.customer_id,
      label: row.label,
      formattedLine: [row.line1, row.line2, row.kecamatan, row.kabupaten_kota, row.province, row.postal_code].filter((part): part is string => typeof part === "string" && part.trim().length > 0).join(", "),
      kecamatan: row.kecamatan,
      kabupatenKota: row.kabupaten_kota,
      latitude: row.latitude === null ? null : Number(row.latitude),
      longitude: row.longitude === null ? null : Number(row.longitude),
      isDefault: row.is_default,
    })),
    serviceAreas: (serviceAreaResult.data ?? []).map((row) => ({
      branchId: row.branch_id,
      kecamatan: row.kecamatan,
      kabupatenKota: row.kabupaten_kota,
      travelFee: Number(row.travel_fee),
      estimatedTravelMinutes: row.estimated_travel_minutes,
    })),
    bookings: bookingRows.map((row) => ({
      id: row.id,
      branchId: row.branch_id,
      customerName: customerNames.get(row.customer_id) ?? "Pelanggan",
      petNames: embeddedPetNames(row.grooming_jobs),
      startsAt: row.starts_at,
      endsAt: row.ends_at,
      status: row.status,
      fulfillmentMode: row.fulfillment_mode,
    })),
  };
}
