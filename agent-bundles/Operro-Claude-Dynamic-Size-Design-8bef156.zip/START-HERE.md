# Operro agent task bundle

Base commit: 8bef156aa745aa958c329adeae66b2cba7cf0ccf
Task: claude-dynamic-size-design

Read ASSIGNMENT.md, then PART_MANIFEST.txt. Source files live under operro/.
This archive intentionally excludes .env files, credentials, node_modules, production dumps, and unlisted repository files.
