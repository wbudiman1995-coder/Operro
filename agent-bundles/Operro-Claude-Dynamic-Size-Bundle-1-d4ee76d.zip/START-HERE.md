# Operro agent task bundle

Base commit: 
d4ee76d4882ca4b4c73524c4fea175f9a669f81b
Task: claude-dynamic-size-bundle-1

Read ASSIGNMENT.md, then PART_MANIFEST.txt. Source files live under operro/.
This archive intentionally excludes .env files, credentials, node_modules, production dumps, and unlisted repository files.
