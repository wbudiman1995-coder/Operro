# Operro agent task bundle

Base commit: 
5d454fe
Task: deepseek-customer-360-edit

Read ASSIGNMENT.md, then PART_MANIFEST.txt. Source files live under operro/.
This archive intentionally excludes .env files, credentials, node_modules, production dumps, and unlisted repository files.
