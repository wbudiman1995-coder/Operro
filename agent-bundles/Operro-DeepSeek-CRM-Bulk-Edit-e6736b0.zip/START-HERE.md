# Operro agent task bundle

Base commit: 
e6736b045db801e5c62aaee96bdcc6162a04e2f1
Task: deepseek-crm-bulk-edit

Read ASSIGNMENT.md, then PART_MANIFEST.txt. Source files live under operro/.
This archive intentionally excludes .env files, credentials, node_modules, production dumps, and unlisted repository files.
