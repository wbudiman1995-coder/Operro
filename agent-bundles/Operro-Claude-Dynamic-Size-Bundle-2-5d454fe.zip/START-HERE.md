# Operro agent task bundle

Base commit: 
5d454fe
Task: claude-dynamic-size-bundle-2

Read ASSIGNMENT.md, then PART_MANIFEST.txt. Source files live under operro/.
This archive intentionally excludes .env files, credentials, node_modules, production dumps, and unlisted repository files.
