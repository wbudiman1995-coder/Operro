"use client";

import { useActionState, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import {
  issueAccessInviteAction, issueOperroInvoiceAction, prepareOrganizationAction, setAdminPermissionsAction,
  setBillingPeriodAction, setMemberRoleAction, setOrganizationStatusAction, type AccessState,
} from "@/app/platform/actions";

const initial: AccessState = { error: null, success: null };
type Access = { members: { email: string; role: string; status: string }[]; admin_keys: string[]; options: { key: string; description: string | null }[] };

export function OpenOrganizationButton({ organizationId }: { organizationId: string }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  async function open() {
    setBusy(true); setError("");
    try {
      const supabase = createClient();
      const result = await supabase.rpc("set_active_organization", { p_organization_id: organizationId });
      if (result.error || result.data !== organizationId) throw new Error("switch_failed");
      const refreshed = await supabase.auth.refreshSession();
      if (refreshed.error || !refreshed.data.session) throw new Error("refresh_failed");
      const claims = await supabase.auth.getClaims(refreshed.data.session.access_token);
      if (claims.error || claims.data?.claims?.active_org_id !== organizationId) throw new Error("claim_mismatch");
      router.push("/dashboard"); router.refresh();
    } catch { setError("Workspace belum dapat dibuka. Muat ulang lalu coba lagi."); setBusy(false); }
  }
  return <span className="inline-flex flex-col gap-1"><button type="button" onClick={open} disabled={busy} className="rounded-lg bg-emerald-700 px-3 py-2 text-xs font-bold text-white disabled:opacity-50">{busy ? "Membuka…" : "Buka workspace ini"}</button>{error ? <span role="status" className="text-xs text-rose-700">{error}</span> : null}</span>;
}

function Feedback({ state }: { state: AccessState }) { return state.error || state.success ? <p role="status" className={`mt-2 text-xs font-semibold ${state.error ? "text-rose-700" : "text-emerald-700"}`}>{state.error ?? state.success}</p> : null; }

export function OrganizationPreparationForm() {
  const [state, action, pending] = useActionState(prepareOrganizationAction, initial);
  return <form action={action} className="space-y-3 rounded-2xl border bg-white p-5"><h2 className="font-bold">Siapkan organisasi baru</h2><p className="text-xs text-slate-500">Membuat workspace trial, cabang utama, izin dasar, dan role Pemilik/Admin/Bantuan Operro/Groomer. Buat link Pemilik setelahnya.</p><div className="grid gap-3 sm:grid-cols-2"><label className="text-xs font-semibold">Nama bisnis<input name="name" required minLength={2} maxLength={100} className="mt-1 h-10 w-full rounded-lg border px-3" /></label><label className="text-xs font-semibold">Slug unik<input name="slug" required pattern="[a-z0-9]+(-[a-z0-9]+)*" placeholder="contoh-grooming" className="mt-1 h-10 w-full rounded-lg border px-3" /></label></div><button disabled={pending} className="rounded-lg bg-emerald-700 px-4 py-2 text-xs font-bold text-white disabled:opacity-50">{pending ? "Menyiapkan…" : "Buat workspace"}</button><Feedback state={state} /></form>;
}

export function AccessInvitationForm({ organizationId, platform, organizationStatus }: { organizationId: string; platform: boolean; organizationStatus?: string }) {
  const [state, action, pending] = useActionState(issueAccessInviteAction, initial);
  const [copied, setCopied] = useState(false);
  const [recipient, setRecipient] = useState("");
  const origin = typeof window !== "undefined" && window.location.hostname.endsWith(".vercel.app")
    ? "https://operro-web.vercel.app" : typeof window !== "undefined" ? window.location.origin : "";
  const link = state.linkPath ? `${origin}${state.linkPath}` : "";
  const suspended = organizationStatus === "suspended";
  return <form action={action} className="space-y-3 rounded-2xl border bg-white p-5"><input type="hidden" name="organizationId" value={organizationId} /><h2 className="font-bold">Link undangan akun</h2><p className="text-xs leading-5 text-slate-500">Link pendaftaran berlaku sekali selama tujuh hari. Setelah diterima, akses email tetap aktif tanpa tanggal kedaluwarsa sampai pemilik bisnis atau Operro menangguhkannya. Akun dibuat di Operro dengan Supabase Auth; penerima tidak perlu akun Vercel.</p>{suspended ? <p role="status" className="rounded-lg bg-amber-50 p-3 text-xs font-semibold text-amber-900">Organisasi ini sedang ditangguhkan. Aktifkan kembali sebelum membuat undangan.</p> : null}<div className="grid gap-3 sm:grid-cols-[1fr_170px_auto]"><input name="email" type="email" required placeholder="email@bisnis.com" aria-label="Email penerima" value={recipient} onChange={(event) => setRecipient(event.target.value)} className="h-10 min-w-0 rounded-lg border px-3 text-sm" /><select name="role" aria-label="Peran undangan" className="h-10 rounded-lg border px-2 text-xs"><option value="Admin">Admin bisnis</option><option value="Groomer">Groomer</option>{platform ? <><option value="Pemilik">Pemilik bisnis</option><option value="Bantuan Operro">Bantuan Operro (tanpa payroll)</option></> : null}</select><button disabled={pending || suspended} className="h-10 rounded-lg bg-emerald-700 px-4 text-xs font-bold text-white disabled:opacity-50">{pending ? "Membuat…" : "Buat link"}</button></div><Feedback state={state} />{link ? <div className="flex flex-wrap gap-2"><input readOnly value={link} aria-label="Link undangan" className="h-10 min-w-48 flex-1 rounded-lg border px-2 text-xs" /><button type="button" onClick={() => navigator.clipboard.writeText(link).then(() => setCopied(true)).catch(() => setCopied(false))} className="rounded-lg border px-3 text-xs font-bold">{copied ? "Tersalin" : "Salin"}</button><a href={`mailto:${encodeURIComponent(recipient)}?subject=${encodeURIComponent("Undangan Operro")}&body=${encodeURIComponent(`Buka link undangan Operro: ${link}`)}`} className="grid place-items-center rounded-lg border px-3 text-xs font-bold">Kirim lewat email</a></div> : null}</form>;
}

function MemberEditor({ organizationId, member, platform }: { organizationId: string; member: Access["members"][number]; platform: boolean }) {
  const [state, action, pending] = useActionState(setMemberRoleAction, initial);
  if (!platform && (["Pemilik", "Owner", "Pemilik Demo", "Bantuan Operro"].includes(member.role))) {
    return <p className="border-t py-3 text-xs"><strong>{member.email}</strong> · {member.role} · {member.status} · dikelola pemilik Operro</p>;
  }
  return <form action={action} className="flex flex-wrap items-center gap-2 border-t py-3 text-xs"><input type="hidden" name="organizationId" value={organizationId} /><input type="hidden" name="email" value={member.email} /><span className="min-w-44 flex-1 font-semibold">{member.email}</span><select name="role" defaultValue={member.role} aria-label={`Peran ${member.email}`} className="h-9 rounded-lg border px-2"><option value="Admin">Admin</option><option value="Groomer">Groomer</option>{platform || member.role === "Pemilik" ? <option value="Pemilik">Pemilik</option> : null}{platform || member.role === "Bantuan Operro" ? <option value="Bantuan Operro">Bantuan Operro</option> : null}</select><select name="status" defaultValue={member.status} aria-label={`Status ${member.email}`} className="h-9 rounded-lg border px-2"><option value="active">Aktif</option><option value="suspended">Tangguhkan</option></select><button disabled={pending} className="h-9 rounded-lg border px-3 font-bold">Simpan</button><Feedback state={state} /></form>;
}

export function OrganizationAccessManager({ organizationId, access, platform, organizationStatus }: { organizationId: string; access: Access; platform: boolean; organizationStatus?: string }) {
  const [state, action, pending] = useActionState(setAdminPermissionsAction, initial);
  return <div className="space-y-5">{platform ? <AccessInvitationForm organizationId={organizationId} platform organizationStatus={organizationStatus} /> : null}<section className="rounded-2xl border bg-white p-5"><h2 className="font-bold">Akses per email</h2><p className="mt-1 text-xs text-slate-500">Perubahan berlaku untuk organisasi ini saja. Menangguhkan akun tidak menghapus datanya.</p><div className="mt-3">{access.members.map(member => <MemberEditor key={member.email} organizationId={organizationId} member={member} platform={platform} />)}</div></section>{!platform ? <form action={action} className="rounded-2xl border bg-white p-5"><input type="hidden" name="organizationId" value={organizationId} /><h2 className="font-bold">Checklist izin Admin bisnis</h2><p className="mt-1 text-xs leading-5 text-slate-500">Pemilik memilih akses untuk semua anggota dengan peran Admin di organisasi ini. Izin mengelola role/anggota dan akses Bantuan Operro tidak dapat diubah di sini.</p><div className="mt-4 grid gap-2 sm:grid-cols-2 xl:grid-cols-3">{access.options.map(option => <label key={option.key} className="flex items-start gap-2 rounded-lg border p-3 text-xs"><input type="checkbox" name="permissions" value={option.key} defaultChecked={access.admin_keys.includes(option.key)} className="mt-0.5" /><span><strong className="block">{option.key}</strong><span className="text-slate-500">{option.description}</span></span></label>)}</div><button disabled={pending} className="mt-4 rounded-lg bg-slate-900 px-4 py-2 text-xs font-bold text-white">{pending ? "Menyimpan…" : "Simpan izin Admin"}</button><Feedback state={state} /></form> : null}</div>;
}

export function OrganizationStatusForm({ organizationId, status }: { organizationId: string; status: string }) {
  const [state, action, pending] = useActionState(setOrganizationStatusAction, initial);
  return <form action={action} className="flex flex-wrap items-end gap-2"><input type="hidden" name="organizationId" value={organizationId} /><label className="text-xs font-semibold">Status<select name="status" defaultValue={status === "suspended" ? "suspended" : "active"} className="mt-1 block h-9 rounded-lg border px-2"><option value="active">Aktif</option><option value="suspended">Tangguhkan</option></select></label><label className="min-w-48 flex-1 text-xs font-semibold">Alasan / status pembayaran<input name="reason" maxLength={500} placeholder="Contoh: pembayaran belum diterima" className="mt-1 h-9 w-full rounded-lg border px-2" /></label><button disabled={pending} className="h-9 rounded-lg border px-3 text-xs font-bold">Simpan status</button><Feedback state={state} /></form>;
}

function IssueOperroInvoiceForm({ organizationId, month }: { organizationId: string; month: string }) {
  const [state, action, pending] = useActionState(issueOperroInvoiceAction, initial);
  return <form action={action} className="mt-2 flex flex-wrap items-center gap-2"><input type="hidden" name="organizationId" value={organizationId} /><input type="hidden" name="month" value={month} /><input name="description" maxLength={300} placeholder="Rincian invoice (opsional)" aria-label={`Rincian invoice ${month}`} className="h-9 min-w-48 flex-1 rounded-lg border px-2" /><button disabled={pending} className="h-9 rounded-lg bg-emerald-700 px-3 font-bold text-white disabled:opacity-50">{pending ? "Menerbitkan…" : "Terbitkan invoice"}</button><Feedback state={state} />{state.linkPath ? <a href={state.linkPath} target="_blank" rel="noreferrer" className="font-bold text-emerald-800 underline">Buka invoice</a> : null}</form>;
}

export function BillingPeriodForm({ organizationId, rows }: { organizationId: string; rows: { month: string; amount: number; due: string; status: string; paid_at: string | null; note: string | null; invoice_id?: string | null; invoice_number?: string | null }[] }) {
  const [state, action, pending] = useActionState(setBillingPeriodAction, initial);
  const currentMonth = new Date().toISOString().slice(0, 7);
  return <section className="rounded-2xl border bg-white p-5"><h2 className="font-bold">Pembayaran langganan manual</h2><p className="mt-1 text-xs text-slate-500">Catat tagihan per bulan, terbitkan invoice Operro, lalu tandai pembayaran setelah diterima. Nominal dan jatuh tempo terkunci setelah invoice terbit.</p><form action={action} className="mt-4 grid gap-3 sm:grid-cols-4"><input type="hidden" name="organizationId" value={organizationId} /><label className="text-xs font-semibold">Bulan<input name="month" type="month" required defaultValue={currentMonth} className="mt-1 h-9 w-full rounded-lg border px-2" /></label><label className="text-xs font-semibold">Nominal Rp<input name="amount" type="number" required min="0" step="1" className="mt-1 h-9 w-full rounded-lg border px-2" /></label><label className="text-xs font-semibold">Jatuh tempo<input name="due" type="date" required className="mt-1 h-9 w-full rounded-lg border px-2" /></label><label className="text-xs font-semibold">Status<select name="status" className="mt-1 h-9 w-full rounded-lg border px-2"><option value="awaiting_payment">Menunggu pembayaran</option><option value="paid">Lunas</option><option value="overdue">Terlambat</option><option value="waived">Dibebaskan</option></select></label><label className="text-xs font-semibold sm:col-span-4">Catatan<input name="note" maxLength={500} className="mt-1 h-9 w-full rounded-lg border px-2" /></label><div className="sm:col-span-4"><button disabled={pending} className="rounded-lg bg-slate-900 px-4 py-2 text-xs font-bold text-white">{pending ? "Menyimpan…" : "Simpan pembayaran"}</button><Feedback state={state} /></div></form><div className="mt-4 space-y-2">{rows.length ? rows.map(row => <div key={row.month} className="rounded-lg bg-slate-50 p-3 text-xs"><p>{row.month} · Rp {Number(row.amount).toLocaleString("id-ID")} · jatuh tempo {row.due} · {row.status}{row.paid_at ? ` · dibayar ${new Date(row.paid_at).toLocaleDateString("id-ID")}` : ""}{row.note ? ` · ${row.note}` : ""}</p>{row.invoice_id ? <a href={`/billing/${row.invoice_id}`} target="_blank" rel="noreferrer" className="mt-2 inline-block font-bold text-emerald-800 underline">{row.invoice_number} · buka / unduh invoice</a> : row.amount > 0 && row.status !== "waived" ? <IssueOperroInvoiceForm organizationId={organizationId} month={row.month} /> : null}</div>) : <p className="text-xs text-slate-500">Belum ada catatan pembayaran.</p>}</div></section>;
}
