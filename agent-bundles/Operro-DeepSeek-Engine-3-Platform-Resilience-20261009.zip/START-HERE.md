# Operro DeepSeek chat packet

Read DEEPSEEK_PROMPT.md, then PART_MANIFEST.txt. Source lives under operro/.
This packet is curated context, not permission to access unlisted files, credentials, production, or provider accounts.
Return patches with paths relative to operro/.
